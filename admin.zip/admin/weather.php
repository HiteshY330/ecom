<?php
$city_name= 'Mumbai';
$api_key = 'f0ec6f9b76adac0d8dc61999eba0d02a';
$api_url='http://api.openweathermap.org/data/2.5/weather?q='.$city_name.'&appid='.$api_key;
$ 
?>